# LDOC Studio Pro VIP Edition for iOS (iPad & iPhone)

## License Status
- License Key: `LDOC-PRO-VIP-2026-LIFETIME-MASTER`
- Licensee: `VIP Lifetime Customer`
- Status: **Pre-Activated / Lifetime Pro Unlocked**
- Architecture: Apple WebKit WKWebView Native Xcode Project & Standalone Web Clips

## Installation
1. Open `ldoc-ios-xcode-project.zip` in Xcode, build and deploy to device.
2. Or use `ldoc-ios-setup.zip` for enterprise mobile deployment.
